'''
A quick script to generate the default database.
'''

import os
import sys

import interface
from database import FieldType, database

# Shenanigans to allow importing from a parent directory
sys.path.insert(1, os.path.join(sys.path[0], ".."))

from config import CONFIG

database.add_table("users",
        ("username", FieldType.STR),
        ("pass_hash", FieldType.BYT),
        ("salt", FieldType.BYT)
    )

# Add an admin user
interface.register_user("admin", "password")

database.write_to_file(CONFIG["BACKUP_DATABASE_PATH"])
print(f"Succesfully created the default database at `{CONFIG['BACKUP_DATABASE_PATH']}`")
