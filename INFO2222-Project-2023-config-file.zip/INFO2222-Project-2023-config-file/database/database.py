'''
A "no-sql" database using custom classes that inherit from python's dictionary objects.
Will 'type-check' new entries to ensure they match the table they are being added to.
Supports creation of multiple tables, adding and removing entries from tables,
and searching for entries in tables based on the value of a field, or the EntryId.
'''

from collections import UserDict
from enum import Enum, unique
import json
import os
from sys import stderr, path
from typing import Any, Optional, Union

# Shenanigans to allow importing from a parent directory
path.insert(1, os.path.join(path[0], ".."))

from config import CONFIG

@unique
class FieldType(Enum):
    '''
    All the possible types that a field in the database could be.
    '''
    STR = str
    INT = int
    BYT = bytes

    @staticmethod
    def from_str(string: str) -> 'FieldType':
        '''
        Get a FieldType t from str(t).
        Raises TypeError if there is no corresponding FieldType.
        '''
        for name, variant in FieldType.__members__.items():
            if name == string:
                return variant
        raise TypeError(f"`{string}` is not a valid FieldType.")

FieldTypeUnion = Union[int, str, bytes]


EntryId = int
class EntryIdGenerator():
    '''
    A 'static' class that generates EntityIds.
    '''
    __next_id: int = 0

    @classmethod
    def new(cls) -> EntryId:
        '''
        Get the next EntityId
        '''
        res = cls.__next_id
        cls.__next_id += 1
        return res

    @classmethod
    def init(cls, value: int) -> None:
        '''
        Set the next id to value.
        Use with care: setting to a previously used value could cause problems.
        '''
        cls.__next_id = value


class Entry(UserDict):
    '''
    An entry in a table. Has a value for each field in the table.
    '''
    entry_id: Optional[EntryId]

    def __init__(self, *args):
        super().__init__(*args)
        self.entry_id = None

    def __setitem__(self, key, item):
        if isinstance(key, str):
            return super().__setitem__(key, item)
        raise ValueError("Entry Keys must be Strings!")


class FieldSpec(UserDict):
    '''
    Specifies the names and corresponding value types for a table.
    '''

    def __setitem__(self, key: str, item: FieldType):
        if isinstance(key, str):
            if item in FieldType:
                return super().__setitem__(key, item)
            raise ValueError("Invalid type for field spec; value must be a FieldType")
        raise ValueError("Invalid type for field spec; key must be a string")

    def __str__(self) -> str:
        return str({name: str(ty) for name, ty in self.items()})

    def matches_entry(self, entry: Entry) -> bool:
        '''
        Check whether the given entry meets this field specification.
        '''
        for key, value in entry.items():
            if key not in self.keys() or not isinstance(value, self[key].value):
                return False
        return True


class Table():
    '''
    An actual Table in the database. Has a FieldSpec that decides what fields
    are present and what types they should be.

    Can add, remove, and search for entries.
    '''
    entries: dict[EntryId, Entry]
    fields: FieldSpec
    name: str

    def __init__(self, table_name, *table_fields) -> None:
        self.entries = {}
        self.fields = FieldSpec()
        for field in table_fields:
            try:
                name, f_ty = field
                self.fields[name] = f_ty
            except ValueError as ex:
                raise ValueError(f"Invalid Field specification: {repr(field)}") from ex
        self.name: str = table_name

    def create_entry(self, data: dict[str, FieldTypeUnion]):
        '''
        Inserts an entry with the given data into the table
        Raises a ValueError if the Entry doesn't match the FieldSpec for this table.
        '''
        # Convert the data into an Entry
        data_entry: Entry = Entry(data)
        self.insert_entry(data_entry)

    def insert_entry(self, entry: Entry):
        '''
        Inserts the exact given entry into the table.
        Raises a KeyError if there is an Entry with the same id already in this table.
        Raises a ValueError if the Entry doesn't match the FieldSpec for this table.
        '''
        if entry.entry_id in self.entries:
            raise KeyError(f"This table already has an entry with the key {entry.entry_id}.")
        if not self.fields.matches_entry(entry):
            data = entry.data
            msg = f"Data doesn't match fields for this Table ({self.name!r})."
            msg += f"\nFieldSpec: {self.fields}"
            msg += "\nActual: " + str({field: type(data[field]) for field in data})
            raise ValueError(msg)

        if entry.entry_id is None:
            entry.entry_id = EntryIdGenerator.new()
        # Success
        self.entries[entry.entry_id] = entry

    def remove_entry(self, target_id: EntryId) -> Optional[Entry]:
        '''
        Removes the entry with the given id and returns it.
        If there is no such entry, returns None.
        '''
        try:
            return self.entries.pop(target_id)
        except KeyError:
            return None

    def search_table(self, target_field_name: str, target_value: FieldTypeUnion) -> Optional[Entry]:
        '''
        Search the table given a field name and a target value
        Returns the first entry found that matches
        '''
        if target_field_name not in self.fields.keys():
            raise KeyError(f"No field `{target_field_name}` in this table ({self.name!r}).")

        # Lazy search for matching entries
        for entry in self.entries.values():
            if entry[target_field_name] == target_value:
                return entry

        # Nothing Found
        return None

    def get_by_value(self, target_field_name: str, target_value: FieldTypeUnion) -> list[Entry]:
        '''
        Search the table given a field name and a target values
        Returns the list of all entries that match
        '''
        if target_field_name not in self.fields.keys():
            raise KeyError(f"No field `{target_field_name}` in this table ({self.name!r}).")

        return [entry for entry in self.entries.values()
                if entry[target_field_name] == target_value]

    def get_by_id(self, entry_id: EntryId) -> Optional[Entry]:
        '''
        Retrieves the entry with the given EntryId.
        If there is no such entry, returns None.
        '''
        if entry_id in self.entries:
            return self.entries[entry_id]
        return None

    @staticmethod
    def from_json_dict(name: str, dct: dict[str, Any]) -> 'Table':
        '''
        Obtain a Table from a dictionary representing a JSON object.
        The dictionary should have a `__field_spec__` entry, and a `__entries__` entry.
        '''
        field_spec = [(name, FieldType.from_str(ty)) for name, ty in dct["__field_spec__"].items()]
        table = Table(name, *field_spec)
        for entry_id_str, entry_data in dct["__entries__"].items():
            entry_id = int(entry_id_str)
            entry = Entry(entry_data)
            entry.entry_id = entry_id
            # Attempt type conversions to match the field spec
            for field, f_ty in field_spec:
                if f_ty == FieldType.BYT:
                    try:
                        entry[field] = bytes(entry[field])
                    except:
                        pass

            table.insert_entry(entry)
        return table


class DB():
    '''
    This is a singleton class that handles all the tables.
    '''
    def __init__(self):
        self.tables = {}

    def add_table(self, table_name: str, *table_fields):
        '''
        Adds a table to the database.
        Will raise a ValueError if *table_fields cannot be converted into a FieldSpec.
        '''
        table = Table(table_name, *table_fields)
        self.tables[table_name] = table

    def search_table(self, table_name: str,
            target_field_name: str, target_value: FieldTypeUnion) -> Optional[Entry]:
        '''
        Calls the search table method on an appropriate table.
        '''
        return self.tables[table_name].search_table(target_field_name, target_value)

    def get_from_table_by_value(self, table_name: str,
            target_field_name: str, target_value: FieldTypeUnion) -> list[Entry]:
        '''
        Calls the get_by_value table method on an appropriate table.
        '''
        return self.tables[table_name].get_by_value(target_field_name, target_value)

    def get_from_table_by_id(self, table_name: str, target_id: EntryId) -> Optional[Entry]:
        '''
        Calls the get_by_value table method on an appropriate table.
        '''
        return self.tables[table_name].get_by_id(target_id)

    def create_table_entry(self, table_name: str, data: dict[str, FieldTypeUnion]):
        '''
        Calls the create entry table method on the appropriate table.
        Raises a ValueError if data doesn't match the FieldSpec for the appropriate table.
        '''
        return self.tables[table_name].create_entry(data)

    def remove_table_entry(self, table_name: str, target_id: EntryId) -> Optional[Entry]:
        '''
        Calls the remove_entry table method on the appropriate table
        '''
        return self.tables[table_name].remove_entry(target_id)

    def write_to_file(self, file_path: str) -> None:
        '''
        Saves the entire database into a JSON file at the specified file-path.
        '''
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(self, file, cls=DatabaseEncoder)

    def load_from_file(self, file_path: str) -> None:
        '''
        Replaces the in-memory database with one loaded from the specified file.
        If the specified file is not valid JSON for a database, raises a TypeError.
        '''
        with open(file_path, "r", encoding="utf-8") as file:
            next_id, new_database_tables = json.load(file, object_hook=database_decode_hook)
            self.tables = new_database_tables
            EntryIdGenerator.init(next_id)


class DatabaseEncoder(json.JSONEncoder):
    '''
    Custom JSON encoder for database pieces.
    '''
    def default(self, o: Any) -> Any:
        if isinstance(o, DB):
            return {"__database__": [
                    {"__table_name__": name, "__table__": self.default(table)} for name, table in o.tables.items()
                    ],
                    "__next_id__": EntryIdGenerator.new()
                }
        if isinstance(o, Table):
            return {"__field_spec__": self.default(o.fields), "__entries__": o.entries}
        if isinstance(o, (FieldSpec, Entry)):
            return o.data
        if isinstance(o, FieldType):
            return o.name
        if isinstance(o, dict):
            return o
        if isinstance(o, bytes):
            return list(o)
        return super().default(o)


def database_decode_hook(dct) -> Union[tuple[int, dict[str, Table]], dict[str, Any]]:
    '''
    Custom JSON decoder hook for database pieces.
    '''
    if "__database__" in dct:
        next_id = 0
        if "__next_id__" in dct:
            next_id = dct["__next_id__"]
        new_database_tables: dict[str, Table] = {}
        for table_dct in dct["__database__"]:
            table = Table.from_json_dict(table_dct["__table_name__"], table_dct["__table__"])
            new_database_tables[table.name] = table
        return (next_id, new_database_tables)
    return dct


# Our global database
# Invoke this as needed
# Don't forget to save it when we're done
database = DB()

def load_database() -> None:
    '''
    Attempt to load the database from the DATABASE_FILE_PATH.
    If this fails, attempt to initialise from the BACKUP_DATABASE_PATH.

    Should be called before any normal database operations.
    '''
    try:
        database.load_from_file(CONFIG["DATABASE_FILE_PATH"])
        print(f"[INFO] Sucessfully loaded database from `{CONFIG['DATABASE_FILE_PATH']}`.")
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(f"[WARNING] Could not load database from `{CONFIG['DATABASE_FILE_PATH']}`, using default database `{CONFIG['BACKUP_DATABASE_PATH']}`.",
                file=stderr)
        print(f"[INFO] {e}", file=stderr)
        # Default database
        try:
            database.load_from_file(CONFIG["BACKUP_DATABASE_PATH"])
            print(f"[INFO] Sucessfully loaded database from `{CONFIG['BACKUP_DATABASE_PATH']}`.")
        except (json.JSONDecodeError, FileNotFoundError) as e2:
            print(f"[WARNING] Could not load backup database from `{CONFIG['BACKUP_DATABASE_PATH']}`.", file=stderr)
            print(f"[INFO] {e2}", file=stderr)


def save_database() -> None:
    '''
    Save the database to the DATABASE_FILE_PATH.

    Should be called just before program exit.
    '''
    database.write_to_file(CONFIG["DATABASE_FILE_PATH"])
    print(f"[INFO] Sucessfully saved database to `{CONFIG['DATABASE_FILE_PATH']}`")
